package com.example.nama_proyek

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
